package com.example.vaaig

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
