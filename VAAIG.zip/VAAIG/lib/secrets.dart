const openAIAPIKey = 'sk-proj-F57PGYAgKl4MbJBC0e1yT3BlbkFJmGizcpsz0A7eD3SEhJkK';
